export const Colors = {
  primary: {
    50: '#e6f7ff',
    100: '#b3e5fc',
    200: '#81d4fa',
    300: '#4fc3f7',
    400: '#29b6f6',
    500: '#0288d1',
    600: '#0277bd',
    700: '#01579b',
    800: '#01457a',
    900: '#003355',
  },
  accent: {
    50: '#e0fff5',
    100: '#b3ffe0',
    200: '#80ffcc',
    300: '#4dffb8',
    400: '#1fffa3',
    500: '#00f597',
    600: '#00cc7a',
    700: '#00a062',
    800: '#007d4d',
    900: '#005a37',
  },
  warning: {
    400: '#ffb74d',
    500: '#ffa726',
    600: '#f57c00',
  },
  error: {
    400: '#ef5350',
    500: '#e53935',
    600: '#c62828',
  },
  neutral: {
    0: '#ffffff',
    50: '#f8fafc',
    100: '#f1f5f9',
    200: '#e2e8f0',
    300: '#cbd5e1',
    400: '#94a3b8',
    500: '#64748b',
    600: '#475569',
    700: '#334155',
    800: '#1e293b',
    900: '#0f172a',
    950: '#020617',
  },
  dark: {
    bg: '#0a0e1a',
    surface: '#111827',
    surfaceHover: '#1a2332',
    border: '#1e293b',
    textPrimary: '#f1f5f9',
    textSecondary: '#94a3b8',
    textMuted: '#64748b',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
};

export const Radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
  pill: 999,
};

export const FontSize = {
  xs: 11,
  sm: 13,
  md: 15,
  lg: 18,
  xl: 22,
  xxl: 28,
  xxxl: 36,
  display: 48,
};

export const Fonts = {
  regular: 'Inter-Regular',
  medium: 'Inter-Medium',
  semiBold: 'Inter-SemiBold',
  bold: 'Inter-Bold',
};

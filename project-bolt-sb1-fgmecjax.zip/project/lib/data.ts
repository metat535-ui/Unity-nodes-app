export type LicenseTier = {
  id: string;
  duration: string;
  split: string;
  userGets: string;
  tag: 'GOOD' | 'RECOMMENDED' | 'BEST';
  dispenserToken: string;
};

export const licenseTiers: LicenseTier[] = [
  {
    id: '3months',
    duration: '3 Months',
    split: '10/90 (UNO/ULO)',
    userGets: '90%',
    tag: 'GOOD',
    dispenserToken: 'd58c980a-df03-49ac-8240-0cc3086d21e4',
  },
  {
    id: '6months',
    duration: '6 Months',
    split: '15/85 (UNO/ULO)',
    userGets: '85%',
    tag: 'RECOMMENDED',
    dispenserToken: 'f21ad7f0-a270-4b80-a495-cd5d9b326214',
  },
  {
    id: '12months',
    duration: '12 Months',
    split: '20/80 (UNO/ULO)',
    userGets: '80%',
    tag: 'BEST',
    dispenserToken: 'd894975e-2c9e-470e-aed4-cfaabea0ca3b',
  },
];

export type TaskInfo = {
  id: string;
  number: number;
  title: string;
  description: string;
  earnings: string;
  earningsRange: string;
  requirement: string;
  icon: string;
  status: 'active' | 'rolling_out' | 'coming_soon';
};

export const tasks: TaskInfo[] = [
  {
    id: 'connection',
    number: 1,
    title: 'Connection to the Network',
    description:
      'The most basic and fully automatic task. Once you install the app and log in, it starts running in the background. Your phone continuously measures network signal, internet speed (latency), and connection reliability.',
    earnings: '0.20 – 0.40 UPS per day',
    earningsRange: '~$6 – $12 per month',
    requirement: 'Internet connection (WiFi or Mobile Data)',
    icon: 'Wifi',
    status: 'active',
  },
  {
    id: 'caller-id',
    number: 2,
    title: 'Caller ID / CLI Testing',
    description:
      'Unetwork sends a test call to your number. Your phone answers it and checks whether the caller ID (CLI) arrived correctly and whether the call routing was tampered with. Helps telecom providers detect fraud and misrouting.',
    earnings: '0.2 – 2 UPS per task',
    earningsRange: 'Per task',
    requirement: 'SIM card (verified phone number)',
    icon: 'Phone',
    status: 'active',
  },
  {
    id: 'sms-testing',
    number: 3,
    title: 'SMS Testing',
    description:
      'Test SMS messages are sent to your number. The app verifies whether the message arrived with the correct Sender ID and whether the content was modified along the way.',
    earnings: '0.2 – 2 UPS per task',
    earningsRange: 'Per task',
    requirement: 'SIM card',
    icon: 'MessageSquare',
    status: 'active',
  },
  {
    id: 'sender-id',
    number: 4,
    title: 'Sender ID & Content Testing',
    description:
      'An advanced version of SMS testing. It checks whether messages arriving as banks or businesses (Sender ID) are genuine or spoofed/spam.',
    earnings: '0.2 – 2 UPS per task',
    earningsRange: 'Per task',
    requirement: 'SIM card',
    icon: 'ShieldCheck',
    status: 'active',
  },
  {
    id: 'telemetry',
    number: 5,
    title: 'Extended Telemetry',
    description:
      'An advanced task, mainly available on iPhone. It collects live network data from your device (signal strength, call quality, etc.) so carriers can understand real-world network performance.',
    earnings: '0.05 – 0.55 UPS per day',
    earningsRange: 'Per day',
    requirement: 'Active license and connected device',
    icon: 'Activity',
    status: 'active',
  },
  {
    id: 'scout',
    number: 6,
    title: 'Scout',
    description:
      'A new advanced task where your phone discovers different network routes and submits the data. Still in early rollout, but the rewards are reported to be significantly higher.',
    earnings: 'Higher than standard (early testers have seen 100+ UPS)',
    earningsRange: 'Significant',
    requirement: 'Currently rolling out',
    icon: 'Compass',
    status: 'rolling_out',
  },
  {
    id: 'runner',
    number: 7,
    title: 'Runner',
    description:
      'Similar to Scout, Runner validates network routes. Each successful validation credits a fixed amount of UP to your account.',
    earnings: 'Fixed UP credit per validation',
    earningsRange: 'Per validation',
    requirement: 'Currently rolling out',
    icon: 'Zap',
    status: 'rolling_out',
  },
  {
    id: 'connectivity-verification',
    number: 8,
    title: 'Connectivity Verification',
    description:
      'A task designed to map network signals and understand connectivity quality across regions. Still in development.',
    earnings: 'To be announced (TBA)',
    earningsRange: 'TBA',
    requirement: 'Coming soon',
    icon: 'Radio',
    status: 'coming_soon',
  },
];

export type SetupStep = {
  step: number;
  title: string;
  description: string;
  details: string[];
};

export const setupSteps: SetupStep[] = [
  {
    step: 1,
    title: 'Download the Unetwork App',
    description:
      'Download the Unetwork app from the Google Play Store or Apple App Store before you begin.',
    details: [
      'Available on Google Play Store for Android 6+',
      'Available on Apple App Store for iOS 15+',
      'Search for "Unetwork" in your respective store',
    ],
  },
  {
    step: 2,
    title: 'Open the Unetwork App',
    description:
      'Open the Unetwork app and select "Unetwork" as your license operator. Confirm that you want to manage licenses from this device.',
    details: [
      'Select "Unetwork" as your license operator',
      'Confirm managing licenses from this device',
      'This establishes your device as an active operator within the Unetwork ecosystem',
    ],
  },
  {
    step: 3,
    title: 'Sign in with Email',
    description:
      'Enter your email address to receive a one-time passcode (OTP). Type your email into the "Your Email" field, then press Continue.',
    details: [
      'Enter your email in the "Your Email" field',
      'Press Continue to receive an OTP',
      'Check your inbox for the OTP and enter it to verify your identity',
    ],
  },
  {
    step: 4,
    title: 'Bind a License',
    description:
      'After signing in, navigate to the Work tab. Here you can bind an available Unetwork License to your device.',
    details: [
      'Navigate to the "Work" tab',
      'Select a license from the list',
      'Tap Continue to bind it to your device',
    ],
  },
  {
    step: 5,
    title: 'Dashboard — Connected',
    description:
      'Once your license is successfully bound, the app dashboard will show a "Connected" status. Your device is now actively contributing to the Unetwork network and earning rewards.',
    details: [
      'Dashboard displays "Connected" status',
      'Your device is actively contributing to the network',
      'Rewards begin accumulating automatically',
    ],
  },
];

export type WithdrawStep = {
  step: number;
  title: string;
  description: string;
  details: string[];
};

export const withdrawSteps: WithdrawStep[] = [
  {
    step: 1,
    title: 'Open the Unetwork Portal',
    description:
      'Go to manage.unitynodes.io and sign in with the same method you use on the mobile app. Your license rewards will load automatically.',
    details: [
      'Visit manage.unitynodes.io',
      'Sign in with the same method as the mobile app',
      'Tap "Get Started" to begin the withdrawal flow',
    ],
  },
  {
    step: 2,
    title: 'Select Your Operator Role',
    description:
      'Choose "Unetwork" as your network operator. This will display your license rewards and available balance.',
    details: [
      'Select "Unetwork" as your network operator',
      'Your license rewards and available balance will appear',
    ],
  },
  {
    step: 3,
    title: 'Complete KYC Verification',
    description:
      'KYC is required for all withdrawals. Upload a government-issued ID (passport or national ID) and provide the required information.',
    details: [
      'Upload a government-issued ID (passport or national ID)',
      'Verification usually takes a few minutes',
      'Once approved, the withdrawal form unlocks',
    ],
  },
  {
    step: 4,
    title: 'Choose Your Payout Method',
    description:
      'Select either Crypto Wallet or Bank Account for your payout method.',
    details: [
      'Crypto Wallet: $5 minimum, $150 maximum per request',
      'Bank Account: 200 UPS minimum, 1000 UPS maximum per request, 1000 UPS daily limit',
      'Supported fiat: USD, EUR, GBP (1 UPS = 1 USD)',
    ],
  },
  {
    step: 5,
    title: 'Confirm and Track',
    description:
      'Review the final quote or bank details carefully, then confirm the withdrawal. You can track the status anytime in the Rewards Overview section of the portal.',
    details: [
      'Review the final quote or bank details carefully',
      'Confirm the withdrawal',
      'Track status anytime in "Rewards Overview" section',
    ],
  },
];

export type FAQItem = {
  question: string;
  answer: string;
};

export const faqItems: FAQItem[] = [
  {
    question: 'Is VPN allowed while running a Unetwork license?',
    answer:
      'No. Using a VPN, proxy, or any IP-masking service while running the Unetwork app is strictly prohibited. The network relies on genuine, real-world device telemetry from your actual location. VPN usage can trigger anti-fraud systems, leading to license termination and loss of all earned rewards.',
  },
  {
    question: 'Can I run one license on multiple devices?',
    answer:
      'No. One device runs one license. Each Unetwork license is bound to a single device and cannot be shared or run simultaneously on multiple devices.',
  },
  {
    question: 'How much can I earn with a Unetwork license?',
    answer:
      'Earnings are demand-based and not guaranteed. A single device can typically earn $0.30 to $1.20 per day, depending on task availability, uptime, location, and carrier demand.',
  },
  {
    question: 'What is the minimum uptime required?',
    answer:
      'Most lease licenses require a minimum uptime of 70% to qualify for rewards.',
  },
  {
    question: 'Does the Unetwork app access my personal calls or messages?',
    answer:
      'No. The app does not route your personal calls, access your contacts, read your messages, or interfere with your SIM.',
  },
  {
    question: 'What is the difference between UNO and ULO?',
    answer:
      'UNO owns the Unetwork Node. ULO runs a licensed device and performs verification tasks. Rewards are split according to the agreed ratio.',
  },
  {
    question: 'How do I withdraw my rewards?',
    answer:
      'Rewards accumulate in the app as UP (Unetwork Points). To withdraw, log in to manage.unitynodes.io with your Unetwork account. Complete KYC, then choose crypto or bank payout.',
  },
  {
    question: 'Is there a minimum device requirement?',
    answer:
      'Yes. You need a compatible Android or iOS device with a stable internet connection. The app requires Android 6+ or iOS 15+.',
  },
];

export type WithdrawFAQItem = {
  question: string;
  answer: string;
};

export const withdrawFaqItems: WithdrawFAQItem[] = [
  {
    question: 'Do crypto and bank withdrawals use the same limits?',
    answer:
      'No. Crypto uses a $5 minimum and $150 maximum per request. Bank uses a 200 UPS minimum, 1000 UPS maximum per request, and 1000 UPS daily limit.',
  },
  {
    question: 'Is KYC required for crypto withdrawals?',
    answer:
      'Yes. KYC is mandatory for both crypto and bank withdrawals. Complete it once in the portal and it unlocks all withdrawal options.',
  },
  {
    question: 'Which fiat currencies are supported?',
    answer:
      'Bank withdrawals support USD, EUR, and GBP. The conversion rate shown is 1 UPS = 1 USD.',
  },
  {
    question: 'Can I withdraw crypto to an exchange wallet?',
    answer:
      'Use caution. Some exchanges require a memo or specific network. A personal wallet is safest if you are unsure.',
  },
];

export const taskTypes = [
  'Connection',
  'Caller ID / CLI',
  'SMS Testing',
  'Sender ID Testing',
  'Extended Telemetry',
  'Scout',
  'Runner',
  'Connectivity Verification',
];

import { StyleSheet, View, ScrollView, TouchableOpacity, Linking, Modal, Text, ActivityIndicator } from 'react-native';
import { useState } from 'react';
import { useRouter } from 'expo-router';
import { WebView } from 'react-native-webview';
import { Zap, ArrowRight, Send, Wallet, ShieldCheck, Activity, Cpu, Globe, BookOpen, ListChecks, X, ExternalLink, KeyRound, Copy, Check } from 'lucide-react-native';
import { Typography } from '@/components/Typography';
import { Card } from '@/components/Card';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';
import { licenseTiers, LicenseTier } from '@/lib/data';

const tagColors = {
  GOOD: Colors.primary[400],
  RECOMMENDED: Colors.accent[400],
  BEST: Colors.warning[400],
};

export default function HomeScreen() {
  const router = useRouter();
  const [selectedTier, setSelectedTier] = useState<LicenseTier | null>(null);

  const quickLinks = [
    { label: 'Setup Guide', icon: BookOpen, route: '/guide' as const },
    { label: 'View Tasks', icon: ListChecks, route: '/tasks' as const },
    { label: 'Withdraw', icon: Wallet, route: '/withdraw' as const },
  ];

  const openDispenser = (tier: LicenseTier) => {
    setSelectedTier(tier);
  };

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
      {/* Hero Section */}
      <View style={styles.hero}>
        <View style={styles.heroBadge}>
          <Zap size={14} color={Colors.accent[400]} strokeWidth={2.5} />
          <Typography variant="label" color={Colors.accent[400]} style={styles.heroBadgeText}>
            DECENTRALIZED NODE INFRASTRUCTURE
          </Typography>
        </View>
        <Typography variant="h1" color={Colors.dark.textPrimary} style={styles.heroTitle}>
          Unity Nodes
        </Typography>
        <Typography variant="h3" color={Colors.primary[300]} style={styles.heroSubtitle}>
          Decentralized Telecom Verification & UNO Licenses
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} style={styles.heroDesc}>
          Earn crypto rewards by validating real-world mobile infrastructure. Run the Unetwork App on your phone and get paid in BTC, ETH, or bank transfer every week.
        </Typography>

        <View style={styles.heroButtons}>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => router.push('/guide')}
            activeOpacity={0.8}
          >
            <Typography variant="label" color={Colors.dark.bg} style={styles.btnText}>
              Get Started
            </Typography>
            <ArrowRight size={16} color={Colors.dark.bg} strokeWidth={2.5} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.secondaryBtn}
            onPress={() => Linking.openURL('https://t.me/UnityLicenseMarketplace')}
            activeOpacity={0.8}
          >
            <Send size={16} color={Colors.primary[300]} strokeWidth={2} />
            <Typography variant="label" color={Colors.primary[300]}>
              Telegram Group
            </Typography>
          </TouchableOpacity>
        </View>
      </View>

      {/* License Tiers */}
      <View style={styles.section}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={styles.sectionTitle}>
          License Tiers
        </Typography>
        <Typography variant="caption" color={Colors.dark.textSecondary} style={styles.sectionDesc}>
          Choose your duration and reward split. Tap a tier to get your license.
        </Typography>

        {licenseTiers.map((tier) => (
          <Card key={tier.id} style={styles.tierCard}>
            <View style={styles.tierHeader}>
              <View style={[styles.tierTag, { backgroundColor: `${tagColors[tier.tag]}20` }]}>
                <Typography variant="label" color={tagColors[tier.tag]} style={styles.tierTagText}>
                  {tier.tag}
                </Typography>
              </View>
              <Typography variant="h3" color={Colors.dark.textPrimary}>
                {tier.duration}
              </Typography>
            </View>
            <View style={styles.tierBody}>
              <View style={styles.tierRow}>
                <Typography variant="caption" color={Colors.dark.textSecondary}>
                  Split Ratio
                </Typography>
                <Typography variant="body" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>
                  {tier.split}
                </Typography>
              </View>
              <View style={styles.tierDivider} />
              <View style={styles.tierRow}>
                <Typography variant="caption" color={Colors.dark.textSecondary}>
                  You Get
                </Typography>
                <Typography variant="h2" color={Colors.accent[400]}>
                  {tier.userGets}
                </Typography>
              </View>
            </View>
            <TouchableOpacity
              style={[styles.getBtn, { backgroundColor: `${tagColors[tier.tag]}20` }]}
              onPress={() => openDispenser(tier)}
              activeOpacity={0.7}
            >
              <Typography variant="label" color={tagColors[tier.tag]} style={{ fontFamily: Fonts.semiBold }}>
                Get This License
              </Typography>
              <ExternalLink size={15} color={tagColors[tier.tag]} strokeWidth={2} />
            </TouchableOpacity>
          </Card>
        ))}
      </View>

      {/* Quick Links */}
      <View style={styles.section}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={styles.sectionTitle}>
          Quick Access
        </Typography>
        <View style={styles.quickGrid}>
          {quickLinks.map((link) => {
            const Icon = link.icon;
            return (
              <TouchableOpacity
                key={link.label}
                style={styles.quickCard}
                onPress={() => router.push(link.route)}
                activeOpacity={0.7}
              >
                <View style={styles.quickIcon}>
                  <Icon size={24} color={Colors.accent[400]} strokeWidth={2} />
                </View>
                <Typography variant="label" color={Colors.dark.textPrimary} align="center">
                  {link.label}
                </Typography>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      {/* Feature Highlights */}
      <View style={styles.section}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={styles.sectionTitle}>
          Why Unity Nodes
        </Typography>
        <View style={styles.featureGrid}>
          <FeatureCard icon={Cpu} title="No Mining Hardware" desc="Software-only nodes — your phone does the work" />
          <FeatureCard icon={ShieldCheck} title="99.9% Uptime" desc="Enterprise-grade validation with immutable logs" />
          <FeatureCard icon={Globe} title="Global Network" desc="Distributed across thousands of verified devices" />
          <FeatureCard icon={Activity} title="Real-Time Sync" desc="Pre-configured licenses with real-time sync networks" />
        </View>
      </View>

      {/* App Download CTA */}
      <Card style={styles.ctaCard}>
        <View style={styles.ctaIconWrap}>
          <Zap size={28} color={Colors.accent[400]} strokeWidth={2} />
        </View>
        <Typography variant="h3" color={Colors.dark.textPrimary} align="center" style={{ marginBottom: Spacing.sm }}>
          Start Earning Today
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} align="center" style={{ marginBottom: Spacing.lg }}>
          Download the Unetwork App and turn your device into a telecom verification node
        </Typography>
        <View style={styles.ctaButtons}>
          <TouchableOpacity
            style={styles.storeBtn}
            onPress={() => Linking.openURL('https://play.google.com/store/apps/details?id=io.unetwork.app')}
            activeOpacity={0.8}
          >
            <Typography variant="label" color={Colors.dark.textPrimary}>
              Google Play
            </Typography>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.storeBtn}
            onPress={() => Linking.openURL('https://apps.apple.com/app/unetwork')}
            activeOpacity={0.8}
          >
            <Typography variant="label" color={Colors.dark.textPrimary}>
              App Store
            </Typography>
          </TouchableOpacity>
        </View>
      </Card>

      {/* Dispenser Modal */}
      <Modal
        visible={selectedTier !== null}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSelectedTier(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <View>
                <Typography variant="h3" color={Colors.dark.textPrimary}>
                  {selectedTier?.duration} — {selectedTier?.userGets}
                </Typography>
                <Typography variant="caption" color={Colors.dark.textSecondary}>
                  {selectedTier?.split}
                </Typography>
              </View>
              <TouchableOpacity onPress={() => setSelectedTier(null)} activeOpacity={0.7}>
                <X size={22} color={Colors.dark.textMuted} strokeWidth={2} />
              </TouchableOpacity>
            </View>
            <View style={styles.modalBody}>
              <DispenserContent tier={selectedTier} />
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

function DispenserContent({ tier }: { tier: LicenseTier | null }) {
  const [webLoading, setWebLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  if (!tier) return null;

  if (!tier.dispenserToken) {
    return (
      <View style={styles.noTokenWrap}>
        <View style={styles.noTokenIcon}>
          <KeyRound size={28} color={Colors.warning[400]} strokeWidth={2} />
        </View>
        <Typography variant="body" color={Colors.dark.textSecondary} align="center" style={{ marginTop: Spacing.md }}>
          This license tier is coming soon. Please check back later or join our Telegram group for updates.
        </Typography>
        <TouchableOpacity
          style={styles.telegramModalBtn}
          onPress={() => Linking.openURL('https://t.me/UnityLicenseMarketplace')}
          activeOpacity={0.8}
        >
          <Typography variant="label" color={Colors.dark.bg} style={{ fontFamily: Fonts.semiBold }}>
            Join Telegram
          </Typography>
        </TouchableOpacity>
      </View>
    );
  }

  const dispenserHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
      <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
          background: #111827;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          display: flex;
          justify-content: center;
          align-items: flex-start;
          min-height: 100vh;
          padding: 16px;
        }
        .udash-nuclear-box {
          width: 100%;
          max-width: 400px;
        }
      </style>
      <script src="https://udash.xyz/embed/dispenser.js"></script>
    </head>
    <body>
      <div class="udash-nuclear-box" data-udash-dispenser data-token="${tier.dispenserToken}"></div>
      <script>
        // Fallback: if the dispenser script doesn't load, render a manual button
        setTimeout(function() {
          var box = document.querySelector('.udash-nuclear-box');
          if (box && box.children.length === 0) {
            box.innerHTML = '<div style="text-align:center;padding:20px;background:#1a2332;border-radius:12px;">' +
              '<p style="color:#94a3b8;font-size:14px;margin-bottom:16px;">Click below to generate your license code</p>' +
              '<a href="https://udash.xyz/dispenser/${tier.dispenserToken}" target="_blank" style="display:inline-block;background:#00f597;color:#0a0e1a;text-decoration:none;padding:12px 32px;border-radius:8px;font-weight:600;font-size:15px;">Generate License Code</a>' +
              '</div>';
          }
        }, 3000);
      </script>
    </body>
    </html>
  `;

  return (
    <View style={styles.dispenserWrap}>
      <Typography variant="caption" color={Colors.dark.textSecondary} align="center" style={{ marginBottom: Spacing.md }}>
        Tap below to generate your Unetwork license code, then enter it in the Unetwork app.
      </Typography>
      <View style={styles.webviewContainer}>
        {webLoading && (
          <View style={styles.webLoadingWrap}>
            <ActivityIndicator size="small" color={Colors.accent[400]} />
            <Typography variant="caption" color={Colors.dark.textMuted} style={{ marginTop: Spacing.sm }}>
              Loading dispenser...
            </Typography>
          </View>
        )}
        <WebView
          source={{ html: dispenserHtml }}
          style={styles.webview}
          onLoad={() => setWebLoading(false)}
          onNavigationStateChange={(navState) => {
            if (navState.url && navState.url !== 'about:blank') {
              Linking.openURL(navState.url).catch(() => {});
            }
          }}
          javaScriptEnabled={true}
          domStorageEnabled={true}
          originWhitelist={['*']}
        />
      </View>
      <TouchableOpacity
        style={styles.openBrowserBtn}
        onPress={() => Linking.openURL(`https://udash.xyz/dispenser/${tier.dispenserToken}`)}
        activeOpacity={0.8}
      >
        <ExternalLink size={15} color={Colors.accent[400]} strokeWidth={2} />
        <Typography variant="label" color={Colors.accent[400]} style={{ fontFamily: Fonts.semiBold }}>
          Open in Browser
        </Typography>
      </TouchableOpacity>
    </View>
  );
}

function FeatureCard({ icon: Icon, title, desc }: { icon: any; title: string; desc: string }) {
  return (
    <Card style={styles.featureCard} padding={Spacing.md}>
      <View style={styles.featureIcon}>
        <Icon size={22} color={Colors.primary[300]} strokeWidth={2} />
      </View>
      <Typography variant="label" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm, fontFamily: Fonts.semiBold }}>
        {title}
      </Typography>
      <Typography variant="caption" color={Colors.dark.textSecondary} style={{ marginTop: 2 }}>
        {desc}
      </Typography>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  hero: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.lg,
    paddingBottom: Spacing.xl,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    paddingHorizontal: Spacing.sm + 2,
    paddingVertical: Spacing.xs + 2,
    borderRadius: Radius.pill,
    alignSelf: 'flex-start',
    marginBottom: Spacing.md,
  },
  heroBadgeText: {
    letterSpacing: 0.8,
  },
  heroTitle: {
    marginBottom: 4,
  },
  heroSubtitle: {
    marginBottom: Spacing.md,
  },
  heroDesc: {
    marginBottom: Spacing.xl,
  },
  heroButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.accent[400],
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
  },
  btnText: {
    fontFamily: Fonts.semiBold,
  },
  secondaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: Colors.primary[500],
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  sectionTitle: {
    marginBottom: Spacing.xs,
  },
  sectionDesc: {
    marginBottom: Spacing.md,
  },
  tierCard: {
    marginBottom: Spacing.sm,
  },
  tierHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  tierTag: {
    paddingHorizontal: Spacing.sm + 2,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.sm,
  },
  tierTagText: {
    letterSpacing: 0.5,
  },
  tierBody: {},
  tierRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.xs,
  },
  tierDivider: {
    height: 1,
    backgroundColor: Colors.dark.border,
    marginVertical: Spacing.xs,
  },
  getBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: Spacing.md,
    paddingVertical: Spacing.md - 2,
    borderRadius: Radius.md,
  },
  quickGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  quickCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: Colors.dark.surface,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    padding: Spacing.md,
    alignItems: 'center',
    gap: Spacing.sm,
  },
  quickIcon: {
    width: 44,
    height: 44,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: Spacing.sm,
  },
  featureCard: {
    width: '48%',
  },
  featureIcon: {
    width: 40,
    height: 40,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(2, 136, 209, 0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ctaCard: {
    marginHorizontal: Spacing.lg,
    alignItems: 'center',
    padding: Spacing.xl,
  },
  ctaIconWrap: {
    width: 56,
    height: 56,
    borderRadius: Radius.lg,
    backgroundColor: 'rgba(0, 245, 151, 0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: Spacing.md,
  },
  ctaButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  storeBtn: {
    flex: 1,
    backgroundColor: Colors.dark.surfaceHover,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    backgroundColor: Colors.dark.surface,
    borderTopLeftRadius: Radius.xxl,
    borderTopRightRadius: Radius.xxl,
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: Colors.dark.border,
  },
  modalBody: {
    padding: Spacing.lg,
  },
  dispenserWrap: {
    alignItems: 'center',
  },
  webviewContainer: {
    width: '100%',
    height: 400,
    backgroundColor: Colors.dark.bg,
    borderRadius: Radius.md,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
  webview: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  webLoadingWrap: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1,
  },
  openBrowserBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 1,
    borderColor: Colors.accent[400],
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    marginTop: Spacing.md,
  },
  noTokenWrap: {
    alignItems: 'center',
    paddingVertical: Spacing.lg,
  },
  noTokenIcon: {
    width: 56,
    height: 56,
    borderRadius: Radius.lg,
    backgroundColor: 'rgba(255, 167, 38, 0.12)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  telegramModalBtn: {
    backgroundColor: Colors.primary[400],
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md + 2,
    borderRadius: Radius.md,
    marginTop: Spacing.lg,
  },
});

import { Tabs } from 'expo-router';
import { Home, BookOpen, ListChecks, Wallet, HelpCircle } from 'lucide-react-native';
import { Colors } from '@/lib/theme';

const headerConfig = {
  headerShown: true,
  headerStyle: {
    backgroundColor: Colors.dark.surface,
  },
  headerTintColor: Colors.dark.textPrimary,
  headerTitleStyle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: Colors.dark.textPrimary,
  },
  headerShadowVisible: false,
  headerTitleAlign: 'center' as const,
};

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        ...headerConfig,
        tabBarStyle: {
          backgroundColor: Colors.dark.surface,
          borderTopColor: Colors.dark.border,
          borderTopWidth: 1,
          height: 64,
          paddingBottom: 8,
          paddingTop: 8,
        },
        tabBarActiveTintColor: Colors.accent[400],
        tabBarInactiveTintColor: Colors.dark.textMuted,
        tabBarLabelStyle: {
          fontSize: 11,
          fontFamily: 'Inter-Medium',
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Unity Nodes',
          tabBarIcon: ({ size, color }) => (
            <Home size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="guide"
        options={{
          title: 'Setup Guide',
          tabBarIcon: ({ size, color }) => (
            <BookOpen size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="tasks"
        options={{
          title: 'Tasks',
          tabBarIcon: ({ size, color }) => (
            <ListChecks size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="withdraw"
        options={{
          title: 'Withdraw',
          tabBarIcon: ({ size, color }) => (
            <Wallet size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
      <Tabs.Screen
        name="faq"
        options={{
          title: 'FAQ & About',
          tabBarIcon: ({ size, color }) => (
            <HelpCircle size={size} color={color} strokeWidth={2} />
          ),
        }}
      />
    </Tabs>
  );
}

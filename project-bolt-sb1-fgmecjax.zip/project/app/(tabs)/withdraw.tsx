import { StyleSheet, ScrollView, View, Linking, TouchableOpacity } from 'react-native';
import { LogIn, UserCheck, FileCheck, Wallet, CheckCheck } from 'lucide-react-native';
import { Typography } from '@/components/Typography';
import { Card } from '@/components/Card';
import { AccordionItem } from '@/components/AccordionItem';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';
import { withdrawSteps, withdrawFaqItems } from '@/lib/data';

const stepIcons = [LogIn, UserCheck, FileCheck, Wallet, CheckCheck];

export default function WithdrawScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={styles.header}>
        <Typography variant="h1" color={Colors.dark.textPrimary}>
          Withdraw Rewards
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} style={styles.subtitle}>
          Complete KYC, then choose crypto or bank payout. Here's the full walkthrough.
        </Typography>
      </View>

      {/* Payout Methods Summary */}
      <View style={styles.payoutSection}>
        <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.md }}>
          Payout Methods
        </Typography>
        <Card style={styles.payoutCard}>
          <View style={styles.payoutHeader}>
            <View style={[styles.payoutIcon, { backgroundColor: 'rgba(255, 167, 38, 0.12)' }]}>
              <Wallet size={20} color={Colors.warning[400]} strokeWidth={2} />
            </View>
            <Typography variant="h3" color={Colors.dark.textPrimary}>
              Crypto Wallet
            </Typography>
          </View>
          <View style={styles.payoutDetails}>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Minimum</Typography>
              <Typography variant="body" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>$5</Typography>
            </View>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Maximum</Typography>
              <Typography variant="body" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>$150 per request</Typography>
            </View>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Currencies</Typography>
              <Typography variant="caption" color={Colors.dark.textSecondary}>BTC, ETH</Typography>
            </View>
          </View>
        </Card>

        <Card style={styles.payoutCard}>
          <View style={styles.payoutHeader}>
            <View style={[styles.payoutIcon, { backgroundColor: 'rgba(2, 136, 209, 0.12)' }]}>
              <Wallet size={20} color={Colors.primary[300]} strokeWidth={2} />
            </View>
            <Typography variant="h3" color={Colors.dark.textPrimary}>
              Bank Account
            </Typography>
          </View>
          <View style={styles.payoutDetails}>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Minimum</Typography>
              <Typography variant="body" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>200 UPS</Typography>
            </View>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Maximum</Typography>
              <Typography variant="body" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>1000 UPS / day</Typography>
            </View>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Currencies</Typography>
              <Typography variant="caption" color={Colors.dark.textSecondary}>USD, EUR, GBP</Typography>
            </View>
            <View style={styles.payoutRow}>
              <Typography variant="caption" color={Colors.dark.textMuted}>Rate</Typography>
              <Typography variant="caption" color={Colors.dark.textSecondary}>1 UPS = 1 USD</Typography>
            </View>
          </View>
        </Card>
      </View>

      {/* Steps */}
      <View style={styles.stepsSection}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.lg }}>
          Withdrawal Steps
        </Typography>
        {withdrawSteps.map((step, index) => {
          const Icon = stepIcons[index] || CheckCheck;
          const isLast = index === withdrawSteps.length - 1;
          return (
            <View key={step.step} style={styles.stepWrap}>
              <View style={styles.stepConnector}>
                <View style={styles.stepIconWrap}>
                  <Icon size={20} color={Colors.primary[300]} strokeWidth={2} />
                </View>
                {!isLast && <View style={styles.connectorLine} />}
              </View>
              <Card style={[styles.stepCard, { marginBottom: isLast ? 0 : Spacing.md }]}>
                <View style={styles.stepNumber}>
                  <Typography variant="label" color={Colors.primary[300]} style={{ fontFamily: Fonts.bold }}>
                    STEP {step.step}
                  </Typography>
                </View>
                <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm }}>
                  {step.title}
                </Typography>
                <Typography variant="body" color={Colors.dark.textSecondary} style={{ marginTop: Spacing.xs }}>
                  {step.description}
                </Typography>
                <View style={styles.detailList}>
                  {step.details.map((detail, i) => (
                    <View key={i} style={styles.detailItem}>
                      <View style={styles.bullet} />
                      <Typography variant="caption" color={Colors.dark.textSecondary} style={{ flex: 1 }}>
                        {detail}
                      </Typography>
                    </View>
                  ))}
                </View>
              </Card>
            </View>
          );
        })}
      </View>

      {/* Withdrawal FAQ */}
      <View style={styles.faqSection}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.md }}>
          Withdrawal FAQ
        </Typography>
        {withdrawFaqItems.map((item, i) => (
          <AccordionItem key={i} question={item.question}>
            <Typography variant="body" color={Colors.dark.textSecondary}>
              {item.answer}
            </Typography>
          </AccordionItem>
        ))}
      </View>

      {/* CTA */}
      <Card style={styles.ctaCard}>
        <Typography variant="h3" color={Colors.dark.textPrimary} align="center" style={{ marginBottom: Spacing.sm }}>
          Ready to withdraw?
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} align="center" style={{ marginBottom: Spacing.lg }}>
          Log in to the portal and follow the steps above
        </Typography>
        <TouchableOpacity
          style={styles.portalBtn}
          onPress={() => Linking.openURL('https://manage.unitynodes.io')}
          activeOpacity={0.8}
        >
          <Typography variant="label" color={Colors.dark.bg} style={{ fontFamily: Fonts.semiBold }}>
            Go to Portal
          </Typography>
        </TouchableOpacity>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  subtitle: {
    marginTop: Spacing.sm,
  },
  payoutSection: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.sm,
    marginBottom: Spacing.xl,
  },
  payoutCard: {},
  payoutHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  payoutIcon: {
    width: 40,
    height: 40,
    borderRadius: Radius.md,
    justifyContent: 'center',
    alignItems: 'center',
  },
  payoutDetails: {
    backgroundColor: Colors.dark.bg,
    borderRadius: Radius.md,
    padding: Spacing.md,
  },
  payoutRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.xs,
  },
  stepsSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  stepWrap: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  stepConnector: {
    alignItems: 'center',
    width: 42,
  },
  stepIconWrap: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: 'rgba(2, 136, 209, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(2, 136, 209, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  connectorLine: {
    width: 2,
    flex: 1,
    backgroundColor: Colors.dark.border,
    marginTop: Spacing.xs,
    marginBottom: Spacing.md,
  },
  stepCard: {
    flex: 1,
  },
  stepNumber: {
    backgroundColor: 'rgba(2, 136, 209, 0.1)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.sm,
    alignSelf: 'flex-start',
  },
  detailList: {
    marginTop: Spacing.md,
    gap: Spacing.sm,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  bullet: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: Colors.primary[400],
    marginTop: 7,
  },
  faqSection: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  ctaCard: {
    marginHorizontal: Spacing.lg,
    alignItems: 'center',
    padding: Spacing.xl,
  },
  portalBtn: {
    backgroundColor: Colors.accent[400],
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md + 2,
    borderRadius: Radius.md,
  },
});

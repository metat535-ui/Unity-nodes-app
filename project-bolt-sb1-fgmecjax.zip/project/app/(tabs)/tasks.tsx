import { StyleSheet, ScrollView, View } from 'react-native';
import { Wifi, Phone, MessageSquare, ShieldCheck, Activity, Compass, Zap, Radio } from 'lucide-react-native';
import { Typography } from '@/components/Typography';
import { Card } from '@/components/Card';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';
import { tasks, TaskInfo } from '@/lib/data';

const iconMap: Record<string, any> = {
  Wifi,
  Phone,
  MessageSquare,
  ShieldCheck,
  Activity,
  Compass,
  Zap,
  Radio,
};

const statusConfig = {
  active: { color: Colors.accent[400], label: 'Active', bg: 'rgba(0, 245, 151, 0.12)' },
  rolling_out: { color: Colors.warning[400], label: 'Rolling Out', bg: 'rgba(255, 167, 38, 0.12)' },
  coming_soon: { color: Colors.neutral[400], label: 'Coming Soon', bg: 'rgba(148, 163, 184, 0.12)' },
};

export default function TasksScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={styles.header}>
        <Typography variant="h1" color={Colors.dark.textPrimary}>
          Available Tasks
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} style={styles.subtitle}>
          See what jobs your device can perform on the Unetwork network and their daily earning potential.
        </Typography>
      </View>

      <View style={styles.taskList}>
        {tasks.map((task) => {
          const Icon = iconMap[task.icon] || Wifi;
          const status = statusConfig[task.status];
          return (
            <Card key={task.id} style={styles.taskCard}>
              <View style={styles.taskHeader}>
                <View style={styles.taskIconWrap}>
                  <Icon size={24} color={Colors.accent[400]} strokeWidth={2} />
                </View>
                <View style={styles.taskTitleWrap}>
                  <Typography variant="caption" color={Colors.dark.textMuted} style={{ fontFamily: Fonts.medium }}>
                    TASK {task.number}
                  </Typography>
                  <Typography variant="h3" color={Colors.dark.textPrimary}>
                    {task.title}
                  </Typography>
                </View>
              </View>

              <View style={[styles.statusBadge, { backgroundColor: status.bg }]}>
                <View style={[styles.statusDot, { backgroundColor: status.color }]} />
                <Typography variant="label" color={status.color}>
                  {status.label}
                </Typography>
              </View>

              <Typography variant="body" color={Colors.dark.textSecondary} style={styles.taskDesc}>
                {task.description}
              </Typography>

              <View style={styles.taskMeta}>
                <View style={styles.metaRow}>
                  <Typography variant="label" color={Colors.dark.textMuted}>
                    EARNINGS
                  </Typography>
                  <Typography variant="body" color={Colors.accent[400]} style={{ fontFamily: Fonts.semiBold }}>
                    {task.earnings}
                  </Typography>
                </View>
                <View style={styles.metaDivider} />
                <View style={styles.metaRow}>
                  <Typography variant="label" color={Colors.dark.textMuted}>
                    REQUIREMENT
                  </Typography>
                  <Typography variant="caption" color={Colors.dark.textSecondary} style={{ textAlign: 'right', flex: 1 }}>
                    {task.requirement}
                  </Typography>
                </View>
              </View>
            </Card>
          );
        })}
      </View>

      <View style={styles.notes}>
        <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.sm }}>
          Important Notes
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary}>
          Earnings are demand-based and not guaranteed. A single device can typically earn $0.30 to $1.20 per day, depending on task availability, uptime, location, and carrier demand.
        </Typography>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  subtitle: {
    marginTop: Spacing.sm,
  },
  taskList: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  taskCard: {},
  taskHeader: {
    flexDirection: 'row',
    gap: Spacing.md,
    alignItems: 'center',
  },
  taskIconWrap: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  taskTitleWrap: {
    flex: 1,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: Spacing.sm + 2,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.sm,
    alignSelf: 'flex-start',
    marginTop: Spacing.md,
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  taskDesc: {
    marginTop: Spacing.md,
  },
  taskMeta: {
    marginTop: Spacing.md,
    backgroundColor: Colors.dark.bg,
    borderRadius: Radius.md,
    padding: Spacing.md,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: Spacing.xs,
  },
  metaDivider: {
    height: 1,
    backgroundColor: Colors.dark.border,
    marginVertical: Spacing.xs,
  },
  notes: {
    paddingHorizontal: Spacing.lg,
    marginTop: Spacing.xl,
  },
});

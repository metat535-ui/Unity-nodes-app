import { StyleSheet, ScrollView, View, Linking, TouchableOpacity } from 'react-native';
import { Info, Server, History, ShieldCheck, Cpu, Globe } from 'lucide-react-native';
import { Typography } from '@/components/Typography';
import { Card } from '@/components/Card';
import { AccordionItem } from '@/components/AccordionItem';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';
import { faqItems } from '@/lib/data';

export default function FaqScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={styles.header}>
        <Typography variant="h1" color={Colors.dark.textPrimary}>
          FAQ & About
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} style={styles.subtitle}>
          Everything you need to know about running a Unetwork license
        </Typography>
      </View>

      {/* About Section */}
      <View style={styles.section}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.md }}>
          About Unity Nodes
        </Typography>

        <Card style={styles.aboutCard}>
          <View style={styles.aboutIcon}>
            <Server size={22} color={Colors.accent[400]} strokeWidth={2} />
          </View>
          <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm }}>
            Decentralized Telecom Infrastructure
          </Typography>
          <Typography variant="body" color={Colors.dark.textSecondary} style={{ marginTop: Spacing.xs }}>
            Unity Nodes is a decentralized telecom verification network that lets users earn crypto rewards by validating real-world mobile infrastructure. Software nodes power secure network authentication, signal diagnostics, and data routing — with no mining hardware required.
          </Typography>
        </Card>

        <Card style={styles.aboutCard}>
          <View style={styles.aboutIcon}>
            <History size={22} color={Colors.primary[300]} strokeWidth={2} />
          </View>
          <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm }}>
            Our History
          </Typography>
          <Typography variant="body" color={Colors.dark.textSecondary} style={{ marginTop: Spacing.xs }}>
            Developed to eliminate systemic delays in global telecom channel validation, Unity Nodes transforms idle distributed server resources into high-efficiency software validation nodes running seamlessly 24/7 without requiring heavy backend maintenance.
          </Typography>
        </Card>

        <Card style={styles.aboutCard}>
          <View style={styles.aboutIcon}>
            <Cpu size={22} color={Colors.warning[400]} strokeWidth={2} />
          </View>
          <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm }}>
            The Technical Core
          </Typography>
          <Typography variant="body" color={Colors.dark.textSecondary} style={{ marginTop: Spacing.xs }}>
            The protocol architectures were engineered and are backed directly by the core technical architects responsible for the Minutes Network. The architecture infuses veteran telecom routing knowledge into a highly stable, lightweight node framework built for enterprise-grade handling.
          </Typography>
        </Card>

        <View style={styles.statsRow}>
          <View style={styles.statItem}>
            <ShieldCheck size={20} color={Colors.accent[400]} strokeWidth={2} />
            <Typography variant="h2" color={Colors.dark.textPrimary} style={{ fontSize: FontSize.xl }}>
              99.9%
            </Typography>
            <Typography variant="label" color={Colors.dark.textMuted}>
              Uptime
            </Typography>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Globe size={20} color={Colors.primary[300]} strokeWidth={2} />
            <Typography variant="h2" color={Colors.dark.textPrimary} style={{ fontSize: FontSize.xl }}>
              100%
            </Typography>
            <Typography variant="label" color={Colors.dark.textMuted}>
              Verified Utility
            </Typography>
          </View>
        </View>
      </View>

      {/* FAQ Section */}
      <View style={styles.section}>
        <Typography variant="h2" color={Colors.dark.textPrimary} style={{ marginBottom: Spacing.md }}>
          Frequently Asked Questions
        </Typography>
        {faqItems.map((item, i) => (
          <AccordionItem key={i} question={item.question}>
            <Typography variant="body" color={Colors.dark.textSecondary}>
              {item.answer}
            </Typography>
          </AccordionItem>
        ))}
      </View>

      {/* CTA */}
      <Card style={styles.ctaCard}>
        <View style={styles.ctaIcon}>
          <Info size={24} color={Colors.primary[300]} strokeWidth={2} />
        </View>
        <Typography variant="h3" color={Colors.dark.textPrimary} align="center" style={{ marginTop: Spacing.sm }}>
          Still have questions?
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} align="center" style={{ marginTop: Spacing.xs, marginBottom: Spacing.lg }}>
          Join our Telegram community for support and updates
        </Typography>
        <TouchableOpacity
          style={styles.telegramBtn}
          onPress={() => Linking.openURL('https://t.me/UnityLicenseMarketplace')}
          activeOpacity={0.8}
        >
          <Typography variant="label" color={Colors.dark.bg} style={{ fontFamily: Fonts.semiBold }}>
            Join Telegram Group
          </Typography>
        </TouchableOpacity>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  subtitle: {
    marginTop: Spacing.sm,
  },
  section: {
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.xl,
  },
  aboutCard: {
    marginBottom: Spacing.sm,
  },
  aboutIcon: {
    width: 40,
    height: 40,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.dark.surface,
    borderRadius: Radius.lg,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    padding: Spacing.lg,
    marginTop: Spacing.sm,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statDivider: {
    width: 1,
    height: 48,
    backgroundColor: Colors.dark.border,
    marginHorizontal: Spacing.md,
  },
  ctaCard: {
    marginHorizontal: Spacing.lg,
    alignItems: 'center',
    padding: Spacing.xl,
  },
  ctaIcon: {
    width: 48,
    height: 48,
    borderRadius: Radius.md,
    backgroundColor: 'rgba(2, 136, 209, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  telegramBtn: {
    backgroundColor: Colors.primary[400],
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.md + 2,
    borderRadius: Radius.md,
  },
});

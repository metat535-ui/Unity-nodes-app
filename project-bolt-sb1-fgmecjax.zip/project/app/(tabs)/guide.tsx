import { StyleSheet, ScrollView, View, Linking, TouchableOpacity } from 'react-native';
import { Download, CheckCircle2, Smartphone, Mail, Link2, MonitorPlay } from 'lucide-react-native';
import { Typography } from '@/components/Typography';
import { Card } from '@/components/Card';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';
import { setupSteps } from '@/lib/data';

const stepIcons = [Download, Smartphone, Mail, Link2, MonitorPlay];

export default function GuideScreen() {
  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 40 }}>
      <View style={styles.header}>
        <Typography variant="h1" color={Colors.dark.textPrimary}>
          Setup Guide
        </Typography>
        <Typography variant="body" color={Colors.dark.textSecondary} style={styles.subtitle}>
          How the Unetwork App Works — Earn Crypto from Your Phone. Turn your device into a telecom verification node.
        </Typography>
      </View>

      <View style={styles.notice}>
        <Download size={20} color={Colors.warning[400]} strokeWidth={2} />
        <Typography variant="caption" color={Colors.dark.textSecondary} style={{ flex: 1 }}>
          Before you start: Download the Unetwork app from the Google Play Store or Apple App Store, then follow the steps below.
        </Typography>
      </View>

      <View style={styles.steps}>
        {setupSteps.map((step, index) => {
          const Icon = stepIcons[index] || CheckCircle2;
          const isLast = index === setupSteps.length - 1;
          return (
            <View key={step.step} style={styles.stepWrap}>
              <View style={styles.stepConnector}>
                <View style={styles.stepIconWrap}>
                  <Icon size={22} color={Colors.accent[400]} strokeWidth={2} />
                </View>
                {!isLast && <View style={styles.connectorLine} />}
              </View>
              <Card style={[styles.stepCard, { marginBottom: isLast ? 0 : Spacing.md }]}>
                <View style={styles.stepHeader}>
                  <View style={styles.stepNumber}>
                    <Typography variant="label" color={Colors.accent[400]} style={{ fontFamily: Fonts.bold }}>
                      STEP {step.step}
                    </Typography>
                  </View>
                </View>
                <Typography variant="h3" color={Colors.dark.textPrimary} style={{ marginTop: Spacing.sm }}>
                  {step.title}
                </Typography>
                <Typography variant="body" color={Colors.dark.textSecondary} style={{ marginTop: Spacing.xs }}>
                  {step.description}
                </Typography>
                <View style={styles.detailList}>
                  {step.details.map((detail, i) => (
                    <View key={i} style={styles.detailItem}>
                      <CheckCircle2 size={14} color={Colors.accent[500]} strokeWidth={2} />
                      <Typography variant="caption" color={Colors.dark.textSecondary} style={{ flex: 1 }}>
                        {detail}
                      </Typography>
                    </View>
                  ))}
                </View>
              </Card>
            </View>
          );
        })}
      </View>

      <Card style={styles.ctaCard}>
        <Typography variant="h3" color={Colors.dark.textPrimary} align="center" style={{ marginBottom: Spacing.sm }}>
          Download the App
        </Typography>
        <Typography variant="caption" color={Colors.dark.textSecondary} align="center" style={{ marginBottom: Spacing.lg }}>
          Requires Android 6+ or iOS 15+
        </Typography>
        <View style={styles.ctaButtons}>
          <TouchableOpacity
            style={styles.storeBtn}
            onPress={() => Linking.openURL('https://play.google.com/store/apps/details?id=io.unetwork.app')}
            activeOpacity={0.8}
          >
            <Typography variant="label" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>
              Google Play
            </Typography>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.storeBtn}
            onPress={() => Linking.openURL('https://apps.apple.com/app/unetwork')}
            activeOpacity={0.8}
          >
            <Typography variant="label" color={Colors.dark.textPrimary} style={{ fontFamily: Fonts.semiBold }}>
              App Store
            </Typography>
          </TouchableOpacity>
        </View>
      </Card>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.dark.bg,
  },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.md,
    paddingBottom: Spacing.lg,
  },
  subtitle: {
    marginTop: Spacing.sm,
  },
  notice: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
    backgroundColor: 'rgba(255, 167, 38, 0.1)',
    marginHorizontal: Spacing.lg,
    padding: Spacing.md + 2,
    borderRadius: Radius.md,
    marginBottom: Spacing.xl,
  },
  steps: {
    paddingHorizontal: Spacing.lg,
  },
  stepWrap: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  stepConnector: {
    alignItems: 'center',
    width: 44,
  },
  stepIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(0, 245, 151, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  connectorLine: {
    width: 2,
    flex: 1,
    backgroundColor: Colors.dark.border,
    marginTop: Spacing.xs,
    marginBottom: Spacing.md,
  },
  stepCard: {
    flex: 1,
  },
  stepHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepNumber: {
    backgroundColor: 'rgba(0, 245, 151, 0.1)',
    paddingHorizontal: Spacing.sm,
    paddingVertical: Spacing.xs,
    borderRadius: Radius.sm,
  },
  detailList: {
    marginTop: Spacing.md,
    gap: Spacing.sm,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: Spacing.sm,
  },
  ctaCard: {
    marginHorizontal: Spacing.lg,
    marginTop: Spacing.xl,
    alignItems: 'center',
    padding: Spacing.xl,
  },
  ctaButtons: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  storeBtn: {
    flex: 1,
    backgroundColor: Colors.dark.surfaceHover,
    paddingVertical: Spacing.md,
    borderRadius: Radius.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.dark.border,
  },
});

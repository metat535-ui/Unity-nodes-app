/*
# Create earnings_logs table for UnityNodes earnings tracker

1. New Tables
- `earnings_logs`
  - `id` (uuid, primary key)
  - `date` (date, not null) — the day the earnings were recorded
  - `task_type` (text, not null) — which Unetwork task generated the earnings (e.g. "Connection", "Caller ID", "SMS Testing", etc.)
  - `ups_earned` (numeric, not null) — UP (Unetwork Points) earned that day
  - `usd_value` (numeric, not null) — approximate USD value (1 UPS = 1 USD)
  - `note` (text, nullable) — optional user note
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `earnings_logs`.
- This is a single-tenant app with no sign-in, so allow anon + authenticated CRUD (data is intentionally shared/public).
*/

CREATE TABLE IF NOT EXISTS earnings_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  task_type text NOT NULL,
  ups_earned numeric(10,2) NOT NULL DEFAULT 0,
  usd_value numeric(10,2) NOT NULL DEFAULT 0,
  note text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE earnings_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_earnings" ON earnings_logs;
CREATE POLICY "anon_select_earnings" ON earnings_logs FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_earnings" ON earnings_logs;
CREATE POLICY "anon_insert_earnings" ON earnings_logs FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_earnings" ON earnings_logs;
CREATE POLICY "anon_update_earnings" ON earnings_logs FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_earnings" ON earnings_logs;
CREATE POLICY "anon_delete_earnings" ON earnings_logs FOR DELETE
  TO anon, authenticated USING (true);

import { StyleSheet, Text, TextStyle } from 'react-native';
import { Colors, FontSize, Fonts } from '@/lib/theme';

type TypographyProps = {
  children: React.ReactNode;
  variant?: 'display' | 'h1' | 'h2' | 'h3' | 'body' | 'caption' | 'label';
  color?: string;
  align?: 'auto' | 'left' | 'right' | 'center';
  style?: TextStyle | TextStyle[];
};

const variantMap: Record<string, TextStyle> = {
  display: { fontSize: FontSize.display, fontFamily: Fonts.bold, lineHeight: 52 },
  h1: { fontSize: FontSize.xxxl, fontFamily: Fonts.bold, lineHeight: 42 },
  h2: { fontSize: FontSize.xxl, fontFamily: Fonts.semiBold, lineHeight: 34 },
  h3: { fontSize: FontSize.xl, fontFamily: Fonts.semiBold, lineHeight: 28 },
  body: { fontSize: FontSize.md, fontFamily: Fonts.regular, lineHeight: 24 },
  caption: { fontSize: FontSize.sm, fontFamily: Fonts.regular, lineHeight: 20 },
  label: { fontSize: FontSize.xs, fontFamily: Fonts.medium, lineHeight: 16 },
};

export function Typography({
  children,
  variant = 'body',
  color,
  align = 'auto',
  style,
}: TypographyProps) {
  return (
    <Text
      style={[
        variantMap[variant],
        { color: color ?? Colors.dark.textPrimary, textAlign: align },
        style,
      ]}
    >
      {children}
    </Text>
  );
}

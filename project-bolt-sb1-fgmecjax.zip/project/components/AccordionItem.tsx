import { useState } from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { ChevronDown } from 'lucide-react-native';
import { Colors, FontSize, Fonts, Radius, Spacing } from '@/lib/theme';

type AccordionItemProps = {
  question: string;
  children: React.ReactNode;
};

export function AccordionItem({ question, children }: AccordionItemProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <View style={styles.container}>
      <TouchableOpacity
        style={styles.header}
        onPress={() => setExpanded(!expanded)}
        activeOpacity={0.7}
      >
        <Text style={styles.question}>{question}</Text>
        <ChevronDown
          size={20}
          color={Colors.dark.textSecondary}
          style={{
            transform: [{ rotate: expanded ? '180deg' : '0deg' }],
          }}
        />
      </TouchableOpacity>
      {expanded && <View style={styles.body}>{children}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: Colors.dark.surface,
    borderRadius: Radius.md,
    borderWidth: 1,
    borderColor: Colors.dark.border,
    marginBottom: Spacing.sm,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: Spacing.md + 2,
  },
  question: {
    flex: 1,
    fontFamily: Fonts.semiBold,
    fontSize: FontSize.md,
    color: Colors.dark.textPrimary,
    marginRight: Spacing.sm,
  },
  body: {
    padding: Spacing.md + 2,
    paddingTop: 0,
  },
});
